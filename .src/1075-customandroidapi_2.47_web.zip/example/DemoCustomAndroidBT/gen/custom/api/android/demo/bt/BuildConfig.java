/** Automatically generated file. DO NOT MODIFY */
package custom.api.android.demo.bt;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}