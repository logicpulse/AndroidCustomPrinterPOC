/** Automatically generated file. DO NOT MODIFY */
package custom.api.android.demo.com;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}