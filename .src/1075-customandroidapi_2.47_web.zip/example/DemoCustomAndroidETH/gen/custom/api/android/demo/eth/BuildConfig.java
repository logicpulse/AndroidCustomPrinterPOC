/** Automatically generated file. DO NOT MODIFY */
package custom.api.android.demo.eth;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}