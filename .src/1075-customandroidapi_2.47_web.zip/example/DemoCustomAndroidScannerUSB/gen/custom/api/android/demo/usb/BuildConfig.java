/** Automatically generated file. DO NOT MODIFY */
package custom.api.android.demo.usb;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}