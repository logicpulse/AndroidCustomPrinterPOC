var namespaces =
[
    [ "it", "namespaceit.html", "namespaceit" ]
];