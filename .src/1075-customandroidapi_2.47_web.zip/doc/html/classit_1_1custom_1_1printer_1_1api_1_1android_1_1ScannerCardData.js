var classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData =
[
    [ "CardDataPoint", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint" ],
    [ "ScannerCardData", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#ab1ab7d10e0e67c7ce011c73ab383b913", null ],
    [ "bOriginalBuffer", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#abc1963aaa1c926f2bdfd7b1610db38c6", null ],
    [ "cPoints", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#a25ad9d29c3ae1fe3e791ffd48fb88b00", null ],
    [ "iCardID", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#abb019f225f81882201e692fd0ae9282e", null ]
];