var namespaceit_1_1custom_1_1printer_1_1api_1_1android =
[
    [ "release", "namespaceit_1_1custom_1_1printer_1_1api_1_1android_1_1release.html", null ],
    [ "CustomAndroidAPI", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI" ],
    [ "CustomException", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException" ],
    [ "CustomPrinter", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter" ],
    [ "PrinterFont", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont" ],
    [ "PrinterStatus", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus" ],
    [ "ScannerCardData", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData" ],
    [ "ScannerImage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage" ],
    [ "ScannerStatus", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus" ]
];