var classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI =
[
    [ "getPrinterDriverBT", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#ab5177b48d932482710cd0f2bdafcf5fa", null ],
    [ "getPrinterDriverCOM", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#ab23e4d97cf16103fcf5f36c783805368", null ],
    [ "getPrinterDriverETH", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#aa5b3b79d2d04af9b37a56bf5db9517bf", null ],
    [ "getPrinterDriverETH", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#a6a892e6323bed96d7be4e59226262113", null ],
    [ "getPrinterDriverUSB", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#a30818a8d73ba7ffd2904818888c6189b", null ]
];