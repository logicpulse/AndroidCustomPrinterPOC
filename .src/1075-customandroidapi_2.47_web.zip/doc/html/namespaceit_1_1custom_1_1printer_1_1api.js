var namespaceit_1_1custom_1_1printer_1_1api =
[
    [ "android", "namespaceit_1_1custom_1_1printer_1_1api_1_1android.html", "namespaceit_1_1custom_1_1printer_1_1api_1_1android" ]
];