var classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus =
[
    [ "equals", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a240a35ea2c02fbe90e1561fbe864ea6d", null ],
    [ "stsSCANNERBARCODEFOUND", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#ad6dfc7e928d9782a60eac0010249856c", null ],
    [ "stsSCANNERBARCODENOTFOUND", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a0abf461de015c8d97a4e4f3eda6cb80c", null ],
    [ "stsSCANNERBWCREATED", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a712fabea80dddbabb8dd81f6d1e4a76a", null ],
    [ "stsSCANNERCARDFOUND", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a0358680ff211dadd2cb5d7e973e9f7a3", null ],
    [ "stsSCANNERCARDNOTFOUND", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a90c1ed194f8125f162d3130b9afce51e", null ],
    [ "stsSCANNERENGINEON", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#abc9b6c162f8de965688a5c3e5a5655ee", null ],
    [ "stsSCANNERGRAYCREATED", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#aeb6ac923ccac58fb59aab9506cf5724c", null ],
    [ "stsSCANNERIMAGEROTATE180", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#ab7c9dc83e563c998a60d03500110d4c1", null ],
    [ "stsSCANNERJAM", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a46f9162ad2aab7553525f30e8409a19e", null ],
    [ "stsSCANNEROPEN", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#af172d448725ae7d21ee35d9cc6c53869", null ],
    [ "stsSCANNERPAPEROK", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#abd2547faef3f96ce27d605e95c86b7da", null ],
    [ "stsSCANNERSEARCHBARCODEON", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#aeb0f57b8b653983f15e78fd910bf720b", null ],
    [ "stsSCANNERSEARCHING", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#ac8494b0703acd5458443fca80eced0dc", null ],
    [ "stsSCANNERTICKETPRESENT", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#abe727906ce8300e95e443471fac48216", null ]
];