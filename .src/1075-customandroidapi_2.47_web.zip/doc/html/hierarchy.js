var hierarchy =
[
    [ "it.custom.printer.api.android.ScannerCardData.CardDataPoint", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html", null ],
    [ "it.custom.printer.api.android.CustomAndroidAPI", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html", null ],
    [ "it.custom.printer.api.android.CustomPrinter", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html", null ],
    [ "Exception", null, [
      [ "it.custom.printer.api.android.CustomException", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html", null ]
    ] ],
    [ "it.custom.printer.api.android.PrinterStatus", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html", null ],
    [ "it.custom.printer.api.android.ScannerCardData", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html", null ],
    [ "it.custom.printer.api.android.ScannerImage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html", null ],
    [ "it.custom.printer.api.android.ScannerStatus", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html", null ],
    [ "Serializable", null, [
      [ "it.custom.printer.api.android.PrinterFont", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html", null ]
    ] ]
];