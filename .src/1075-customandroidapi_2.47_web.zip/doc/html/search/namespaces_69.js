var searchData=
[
  ['android',['android',['../namespaceit_1_1custom_1_1printer_1_1api_1_1android.html',1,'it::custom::printer::api']]],
  ['api',['api',['../namespaceit_1_1custom_1_1printer_1_1api.html',1,'it::custom::printer']]],
  ['custom',['custom',['../namespaceit_1_1custom.html',1,'it']]],
  ['it',['it',['../namespaceit.html',1,'']]],
  ['printer',['printer',['../namespaceit_1_1custom_1_1printer.html',1,'it::custom']]],
  ['release',['release',['../namespaceit_1_1custom_1_1printer_1_1api_1_1android_1_1release.html',1,'it::custom::printer::api::android']]]
];
