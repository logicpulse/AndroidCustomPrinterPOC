var searchData=
[
  ['commtype_5fbluetooth',['COMMTYPE_BLUETOOTH',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a3118891b88a74e882213ad83d8d97030',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fcom',['COMMTYPE_COM',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a03f0178b766c001d18d8ee07aaaa8e0f',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fethernet',['COMMTYPE_ETHERNET',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a7ba1a31cd87f8f3416f05cfdceafc2b5',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fusb',['COMMTYPE_USB',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a5ab6c8d719ff98c08df002112220692e',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['cpoints',['cPoints',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#a25ad9d29c3ae1fe3e791ffd48fb88b00',1,'it::custom::printer::api::android::ScannerCardData']]],
  ['cut_5fpartial',['CUT_PARTIAL',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a77ba0963e11c8e3f92261960f744bbdf',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['cut_5ftotal',['CUT_TOTAL',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#aca3f29063d95e81c63c0c7cf824a58d3',1,'it::custom::printer::api::android::CustomPrinter']]]
];
