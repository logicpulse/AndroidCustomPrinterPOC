var searchData=
[
  ['feed',['feed',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#ada2d71410c91ea3925d1f0dced18c5d2',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['fillprinterstatusfromprinterfullstatus',['FillPrinterStatusFromPrinterFullStatus',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a2bbff36836b1884f8894ad327c80313b',1,'it::custom::printer::api::android::PrinterStatus']]],
  ['fillscannerstatusfromscannerfullstatus',['FillScannerStatusFromScannerFullStatus',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#acd428b22d29f49a53ca32bea24b407a0',1,'it::custom::printer::api::android::ScannerStatus']]]
];
