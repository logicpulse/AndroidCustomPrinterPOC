var searchData=
[
  ['carddatapoint',['CardDataPoint',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#ab4815d5a51106bdf903f7049052b9942',1,'it::custom::printer::api::android::ScannerCardData::CardDataPoint']]],
  ['clearreadbuffer',['clearReadBuffer',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#ac2ac0e4b23a5039a556b32553367d014',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['close',['close',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#af2700a05e458ec7012ad136128b19a4d',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['customexception',['CustomException',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#ab8ec49eb585d51c31ec5c9d327800c9a',1,'it.custom.printer.api.android.CustomException.CustomException(long lErrorCode)'],['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a59a837137cab02666107200ddc88f306',1,'it.custom.printer.api.android.CustomException.CustomException(long lErrorCode, String strAddErrorDescr)'],['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#aab53ac3d0c24c753cbf66b15a3543354',1,'it.custom.printer.api.android.CustomException.CustomException(String strMessage)']]],
  ['cut',['cut',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a3af62d2a11390ac8e1d37b9f9bc4dd12',1,'it::custom::printer::api::android::CustomPrinter']]]
];
