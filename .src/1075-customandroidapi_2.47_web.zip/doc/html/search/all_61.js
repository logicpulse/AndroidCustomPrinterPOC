var searchData=
[
  ['a',['A',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#a44cf44b96bc74cd779f5cee5dcda4dae',1,'it::custom::printer::api::android::ScannerCardData::CardDataPoint']]]
];
