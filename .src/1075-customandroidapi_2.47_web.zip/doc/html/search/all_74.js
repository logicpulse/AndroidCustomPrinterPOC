var searchData=
[
  ['tostring',['toString',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a07201e6abf684b04fc604fde0cbbf7f7',1,'it::custom::printer::api::android::CustomException']]]
];
