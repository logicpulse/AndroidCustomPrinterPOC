var searchData=
[
  ['printerfont',['PrinterFont',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html',1,'it::custom::printer::api::android']]],
  ['printerstatus',['PrinterStatus',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html',1,'it::custom::printer::api::android']]]
];
