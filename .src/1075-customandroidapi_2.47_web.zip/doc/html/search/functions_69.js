var searchData=
[
  ['isprintavailable',['isPrintAvailable',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a36755eac363b6656373bdedd8a244cc2',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['isprinteronline',['isPrinterOnline',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a188fb4f2da0c9de55a0593d33b047009',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['isscanneravailable',['isScannerAvailable',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a1dd3c2926e169900ea4a80e6d44a2bed',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['isveriprintavailable',['isVeriprintAvailable',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a52d59940d8f276538dd749d010f9cfc6',1,'it::custom::printer::api::android::CustomPrinter']]]
];
