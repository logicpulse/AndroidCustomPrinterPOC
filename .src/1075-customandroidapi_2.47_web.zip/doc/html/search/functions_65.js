var searchData=
[
  ['eject',['eject',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a5492ba3a41ac37a93f7f211eea680afa',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['enablelogapi',['EnableLogAPI',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#a3469372701f6df48f89792e53dea8213',1,'it::custom::printer::api::android::CustomAndroidAPI']]],
  ['enumbluetoothdevices',['EnumBluetoothDevices',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#a60593e4e4165be3de8810139f6d06aa5',1,'it::custom::printer::api::android::CustomAndroidAPI']]],
  ['enumethernetdevices',['EnumEthernetDevices',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#a1b8a5f71de8ccde10e77ab15aaa3616b',1,'it::custom::printer::api::android::CustomAndroidAPI']]],
  ['enumusbdevices',['EnumUsbDevices',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html#aad4e462bb58529a31f7fc321ba42053a',1,'it::custom::printer::api::android::CustomAndroidAPI']]],
  ['equals',['equals',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a63bf3f1e7964764802cc48506db8315b',1,'it.custom.printer.api.android.PrinterStatus.equals()'],['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html#a240a35ea2c02fbe90e1561fbe864ea6d',1,'it.custom.printer.api.android.ScannerStatus.equals()']]]
];
