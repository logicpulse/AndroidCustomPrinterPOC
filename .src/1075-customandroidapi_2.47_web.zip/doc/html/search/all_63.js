var searchData=
[
  ['carddatapoint',['CardDataPoint',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html',1,'it::custom::printer::api::android::ScannerCardData']]],
  ['carddatapoint',['CardDataPoint',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#ab4815d5a51106bdf903f7049052b9942',1,'it::custom::printer::api::android::ScannerCardData::CardDataPoint']]],
  ['clearreadbuffer',['clearReadBuffer',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#ac2ac0e4b23a5039a556b32553367d014',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['close',['close',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#af2700a05e458ec7012ad136128b19a4d',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fbluetooth',['COMMTYPE_BLUETOOTH',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a3118891b88a74e882213ad83d8d97030',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fcom',['COMMTYPE_COM',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a03f0178b766c001d18d8ee07aaaa8e0f',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fethernet',['COMMTYPE_ETHERNET',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a7ba1a31cd87f8f3416f05cfdceafc2b5',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['commtype_5fusb',['COMMTYPE_USB',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a5ab6c8d719ff98c08df002112220692e',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['cpoints',['cPoints',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#a25ad9d29c3ae1fe3e791ffd48fb88b00',1,'it::custom::printer::api::android::ScannerCardData']]],
  ['customandroidapi',['CustomAndroidAPI',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomAndroidAPI.html',1,'it::custom::printer::api::android']]],
  ['customexception',['CustomException',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#ab8ec49eb585d51c31ec5c9d327800c9a',1,'it.custom.printer.api.android.CustomException.CustomException(long lErrorCode)'],['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a59a837137cab02666107200ddc88f306',1,'it.custom.printer.api.android.CustomException.CustomException(long lErrorCode, String strAddErrorDescr)'],['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#aab53ac3d0c24c753cbf66b15a3543354',1,'it.custom.printer.api.android.CustomException.CustomException(String strMessage)']]],
  ['customexception',['CustomException',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html',1,'it::custom::printer::api::android']]],
  ['customprinter',['CustomPrinter',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html',1,'it::custom::printer::api::android']]],
  ['cut',['cut',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a3af62d2a11390ac8e1d37b9f9bc4dd12',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['cut_5fpartial',['CUT_PARTIAL',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a77ba0963e11c8e3f92261960f744bbdf',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['cut_5ftotal',['CUT_TOTAL',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#aca3f29063d95e81c63c0c7cf824a58d3',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['customandroidapi_20documentation',['CustomAndroidAPI Documentation',['../index.html',1,'']]]
];
