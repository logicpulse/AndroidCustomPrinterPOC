var searchData=
[
  ['readdata',['readData',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a9ad26a806692d545bc016b01b3eafa1d',1,'it::custom::printer::api::android::CustomPrinter']]]
];
