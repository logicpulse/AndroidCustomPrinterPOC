var searchData=
[
  ['ej_5feject',['EJ_EJECT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a7f138e92efd32e1654fa108b24569cfa',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['ej_5fretract',['EJ_RETRACT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#af24e26bb1fadb2d21e9d6d11e33b5dad',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['err_5fdatabarcode',['ERR_DATABARCODE',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a69b0eb8e665da319197ad6afe6d1e16d',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fdatanotavailable',['ERR_DATANOTAVAILABLE',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#aaf579efce5b54894481df12bf84d47fe',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fdevicenotrecognized',['ERR_DEVICENOTRECOGNIZED',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a90e8bc20e92ab178e2fbfba268a69d97',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fdevicenotsupported',['ERR_DEVICENOTSUPPORTED',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a2a36614b3d6e465da1ccffae258c1939',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fgeneric',['ERR_GENERIC',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a536359756387522bf4c31b48c650d55a',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5finitcommunicationerror',['ERR_INITCOMMUNICATIONERROR',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a09ade4a3f8cdd3e1bc518e92b323ee0d',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fprintercommunicationerror',['ERR_PRINTERCOMMUNICATIONERROR',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a6891f426191f50a8106850f26f4a3852',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fprinternotconnected',['ERR_PRINTERNOTCONNECTED',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a377aee31769cb575d8d4665e256aa9e8',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5funsupportedfunction',['ERR_UNSUPPORTEDFUNCTION',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a57511f6caa9ce72bdcd5529f0f1d5bba',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fwrongparametervalue',['ERR_WRONGPARAMETERVALUE',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a4222dc8764917290a767590921dd9f4b',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fwrongpicture',['ERR_WRONGPICTURE',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#ae1c76ea5b427218bf90ca7d3bc220bee',1,'it::custom::printer::api::android::CustomException']]],
  ['err_5fwrongprinterfont',['ERR_WRONGPRINTERFONT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a33bf08397621dddea7759bdc28540580',1,'it::custom::printer::api::android::CustomException']]]
];
