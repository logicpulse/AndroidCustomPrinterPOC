var searchData=
[
  ['icardid',['iCardID',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html#abb019f225f81882201e692fd0ae9282e',1,'it::custom::printer::api::android::ScannerCardData']]],
  ['image',['Image',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a1a75d53d1bf7f1c4f8c6438f00ababe4',1,'it::custom::printer::api::android::ScannerImage']]],
  ['image_5falign_5fto_5fcenter',['IMAGE_ALIGN_TO_CENTER',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#a692fb17ddac01a273002f97d0f3d8d6a',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['image_5falign_5fto_5fleft',['IMAGE_ALIGN_TO_LEFT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#abd972f9fcc32cf458d1fbe0c581a53c9',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['image_5falign_5fto_5fright',['IMAGE_ALIGN_TO_RIGHT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#acf813189ff9cee3c64afed82a53a853e',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['image_5fscale_5fnone',['IMAGE_SCALE_NONE',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#ad2cf45faa56e0a2b36307ca264fa5957',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['image_5fscale_5fto_5ffit',['IMAGE_SCALE_TO_FIT',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#accd423a1c6d27f856e7b06a9cb58fc3d',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['image_5fscale_5fto_5fwidth',['IMAGE_SCALE_TO_WIDTH',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomPrinter.html#af3ecd63bf92b1f5dc8e42cc81983752e',1,'it::custom::printer::api::android::CustomPrinter']]],
  ['imagebitsperpixel',['ImageBitsPerPixel',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a73a37286fa9115080035a5cbb278b3be',1,'it::custom::printer::api::android::ScannerImage']]],
  ['imageheight',['ImageHeight',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a8dca9c6c70ca7116dc0eb6d059e4bc94',1,'it::custom::printer::api::android::ScannerImage']]],
  ['imageinclination',['ImageInclination',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#af031baf1ba3d3a7df808f1016fb986eb',1,'it::custom::printer::api::android::ScannerImage']]],
  ['imagenumcolors',['ImageNumColors',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a3523d83982703f67f581864c39b59a4e',1,'it::custom::printer::api::android::ScannerImage']]],
  ['imagewidth',['ImageWidth',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a298855f736135c0ac90ad9e59d158393',1,'it::custom::printer::api::android::ScannerImage']]]
];
