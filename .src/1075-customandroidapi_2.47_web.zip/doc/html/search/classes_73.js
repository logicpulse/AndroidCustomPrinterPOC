var searchData=
[
  ['scannercarddata',['ScannerCardData',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData.html',1,'it::custom::printer::api::android']]],
  ['scannerimage',['ScannerImage',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html',1,'it::custom::printer::api::android']]],
  ['scannerstatus',['ScannerStatus',['../classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerStatus.html',1,'it::custom::printer::api::android']]]
];
