var namespaceit_1_1custom_1_1printer =
[
    [ "api", "namespaceit_1_1custom_1_1printer_1_1api.html", "namespaceit_1_1custom_1_1printer_1_1api" ]
];