var classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint =
[
    [ "CardDataPoint", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#ab4815d5a51106bdf903f7049052b9942", null ],
    [ "A", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#a44cf44b96bc74cd779f5cee5dcda4dae", null ],
    [ "B", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerCardData_1_1CardDataPoint.html#a4aeb78b85a0d9dd343d640d2efd6ed47", null ]
];