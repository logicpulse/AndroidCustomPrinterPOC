var annotated =
[
    [ "it", "namespaceit.html", "namespaceit" ]
];