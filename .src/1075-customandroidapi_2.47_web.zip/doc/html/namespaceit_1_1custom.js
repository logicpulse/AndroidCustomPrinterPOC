var namespaceit_1_1custom =
[
    [ "printer", "namespaceit_1_1custom_1_1printer.html", "namespaceit_1_1custom_1_1printer" ]
];