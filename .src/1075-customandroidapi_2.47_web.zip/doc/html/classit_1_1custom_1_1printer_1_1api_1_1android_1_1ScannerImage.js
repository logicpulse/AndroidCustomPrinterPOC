var classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage =
[
    [ "ScannerImage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#ad679e53fdf5fe200616c99ce099f6d4a", null ],
    [ "ScannerImage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a159de80e8fb121ae6e6e4c4907ab2cdb", null ],
    [ "Image", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a1a75d53d1bf7f1c4f8c6438f00ababe4", null ],
    [ "ImageBitsPerPixel", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a73a37286fa9115080035a5cbb278b3be", null ],
    [ "ImageHeight", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a8dca9c6c70ca7116dc0eb6d059e4bc94", null ],
    [ "ImageInclination", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#af031baf1ba3d3a7df808f1016fb986eb", null ],
    [ "ImageNumColors", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a3523d83982703f67f581864c39b59a4e", null ],
    [ "ImageWidth", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1ScannerImage.html#a298855f736135c0ac90ad9e59d158393", null ]
];