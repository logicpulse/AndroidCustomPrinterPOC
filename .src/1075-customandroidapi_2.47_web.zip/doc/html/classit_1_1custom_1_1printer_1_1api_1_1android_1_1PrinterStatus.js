var classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus =
[
    [ "equals", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a63bf3f1e7964764802cc48506db8315b", null ],
    [ "stsCUTERROR", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a005e4f2c3796b98d47dc32c4fcd7a60d", null ],
    [ "stsEEPROMERROR", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a00ed8dee6d5d02b1a2e0d53dae530752", null ],
    [ "stsFFPRESSED", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#af4fcb086e63e351e0647d5ef8f1aa599", null ],
    [ "stsHLVOLT", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#ac9c746ad877feb278bc56bdc4504bd14", null ],
    [ "stsLFPRESSED", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#ab791b69b14d2c12e7cbd80fff69af4dd", null ],
    [ "stsNEARENDPAP", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#ae22f75214bf8398bead740084b889c94", null ],
    [ "stsNOCOVER", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#aa99a1538017812e5f062a47af2943d84", null ],
    [ "stsNOHEAD", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a832b966505be72bcedcdc4313f099496", null ],
    [ "stsNOPAPER", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a4d16733605d1304b027a82589e747932", null ],
    [ "stsOVERTEMP", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a27279ab2a439e773bd9d13e4cdde887c", null ],
    [ "stsPAPERJAM", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a012a48d21d67aba5dc4dc59f36f32bef", null ],
    [ "stsPAPERROLLING", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a95150e48fca28534a25d41dd660ab361", null ],
    [ "stsRAMERROR", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#ab22043d11ffd8fcc6adb188ef91a6f87", null ],
    [ "stsSPOOLING", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#a05e07778bc5db0a8858a43bebbe6747b", null ],
    [ "stsTICKETOUT", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterStatus.html#aad6bc712de81839c3afe73e8a7aefc48", null ]
];