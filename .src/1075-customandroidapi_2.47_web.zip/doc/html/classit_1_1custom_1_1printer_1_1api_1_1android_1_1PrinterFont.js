var classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont =
[
    [ "getCharFontType", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a54c86e021336d2d59a5ce3f2bf06f830", null ],
    [ "getCharHeight", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a8162bbd51a013e3cba5cd09aa586ddd5", null ],
    [ "getCharWidth", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#ae059c29fce3a9ac74123cc0368a6af30", null ],
    [ "getEmphasized", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#ad339836912a93a6ca4409e553d84b47e", null ],
    [ "getInternationalCharSet", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a9853e460187ea9565cf38a576734f8ac", null ],
    [ "getInternationalCharSetString", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#aeb0a146c149b68f518370afef9cf4e7c", null ],
    [ "getItalic", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#addb0bc2bad0ef7de3992e523668ff232", null ],
    [ "getJustification", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a438e5fc79f5dd56600f849c9179437aa", null ],
    [ "getUnderline", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#ac4db42884eaaf715f59420179c0274fd", null ],
    [ "setCharFontType", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a073aa87707987f8dfe08a3e07f51f381", null ],
    [ "setCharHeight", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#ac8a7fd38ae37ac024097d733fe0318e4", null ],
    [ "setCharWidth", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a0ebcacac15c15b2ddcc5fdae57b41f06", null ],
    [ "setEmphasized", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#aa325f1386c3f4f33c0507df17cb59f3e", null ],
    [ "setInternationalCharSet", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a12639b419e61ac0a62a0ca7f47d07988", null ],
    [ "setInternationalCharSetString", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#af132ace5cd5ac6446219a42abafe7901", null ],
    [ "setItalic", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#aa8c46f4eb2cf569ff550a8dd061e3b51", null ],
    [ "setJustification", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a9b7c49aff563b5a3fbb2be5e5b99bffb", null ],
    [ "setUnderline", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1PrinterFont.html#a0b2e7e27e658dc518f3bf3169990aa3d", null ]
];