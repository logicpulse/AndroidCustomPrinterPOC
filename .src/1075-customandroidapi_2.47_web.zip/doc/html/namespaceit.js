var namespaceit =
[
    [ "custom", "namespaceit_1_1custom.html", "namespaceit_1_1custom" ]
];