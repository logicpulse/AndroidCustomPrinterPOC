var classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException =
[
    [ "CustomException", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#ab8ec49eb585d51c31ec5c9d327800c9a", null ],
    [ "CustomException", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a59a837137cab02666107200ddc88f306", null ],
    [ "CustomException", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#aab53ac3d0c24c753cbf66b15a3543354", null ],
    [ "getAddMessage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a3b8fbc7a4834a34ed0e1c40bed2a1a95", null ],
    [ "GetErrorCode", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a4e5ebdb7f1c549a5c9e1d0a5dc7ac383", null ],
    [ "getMessage", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a3f6d0b98e59971eb7463dfb34c082e71", null ],
    [ "toString", "classit_1_1custom_1_1printer_1_1api_1_1android_1_1CustomException.html#a07201e6abf684b04fc604fde0cbbf7f7", null ]
];